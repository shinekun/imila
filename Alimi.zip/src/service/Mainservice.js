export default class Mainservice{
    static loadOptions(cb){
        setTimeout(cb,2000);
    }
}