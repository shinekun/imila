import React, { Component } from 'react';
import { StyleSheet, Text, View, Image, TouchableOpacity, AsyncStorage } from 'react-native';
import AlimFlatList from '../components/AlimFlatList'
import axios from 'axios'

export default class AlimList extends Component {
    constructor(props) {
        super();
    }
    _doLogout = () => {
        AsyncStorage.setItem("ISLOGIN", JSON.stringify(false));
        this.props.navigation.replace('Login');
    }
    _doLogin = () => {
        if (this.state.user_id != '' || this.state.user_pw != '') {
            axios.get(`http://tktv.co.kr/api/shop/?id=${this.state.user_id}&password=${this.state.user_pw}`)
                .then(data => {
                    console.log(data);
                    if (data.data.response == "SUCCESS") {
                        AsyncStorage.setItem("ISLOGIN", JSON.stringify(true));
                        this.props.navigation.replace('AlimList');
                    }
                    else
                        alert('로그인에 실패하였습니다')
                });
        }
        else
            alert('아이디와 비밀번호를 입력해주세요')
    }
    _doOpenApi = () => {
        var parseString = require('react-native-xml2js').parseString;
        axios.get(`http://itktv.cafe24.com/alimi/manager/`).then(
            data => {
                parseString(data.data, function (err, result) {
                    console.dir(result);
                    <AlimFlatList />
                })
            }
        );
    }
    render() {
        return ( 
            <View style={styles.container}>
                <View style={styles.viewstyle}>
                    <Text style={styles.txtstyle}>TKTV-인터넷신문/방송</Text>
                    <TouchableOpacity style={styles.touchablestyle} onPress={() => this._doLogout()}>
                        <Image style={{ height: 50, width: 50 }} source={require('../drawable/unlocked.png')} />
                    </TouchableOpacity>
                </View>
                <View>
                    <Text>알림 리스트</Text>
                    <AlimFlatList navigation={this.props.navigation} />
                </View>
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fafafa'
    },
    viewstyle: {
        backgroundColor: '#A6A6A6',
        height: 60,
        justifyContent: 'center',
        flexDirection: 'row',
    },
    txtstyle: {
        flex: 6,
        justifyContent: 'center',
        fontSize: 20,
        margin: 15
    },
    touchablestyle: {
        alignItems: 'flex-end',
        height: '100%',
        flex: 1,
        justifyContent: 'center'
    },
});