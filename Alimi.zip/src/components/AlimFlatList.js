import React, { Component } from 'react';
import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';

export default class AlimFlatList extends Component {
    constructor(props) {
        super();

    }
    render() {
        return (
            <TouchableOpacity onPress={() => { this.props.navigation.navigate('ListDetail') }}>
                <View style={{ flexDirection: 'row' }}>
                    <Text style={styles.numtxtstyle}>번호</Text>
                    <View style={{ flex: 2 }}>
                        <Text style={{ fontSize: 30 }}>이름</Text>
                        <Text>예약일자:     </Text>
                    </View>
                    <View style={styles.reservationviewstyle}>
                        <Text>예약 날짜</Text>
                        <Text>예약 시간</Text>
                    </View>
                </View>
            </TouchableOpacity>
        );
    }
}
const styles = StyleSheet.create({
    numtxtstyle: {
        justifyContent: 'flex-start',
        flex: 0.3
    },
    reservationviewstyle: {
        justifyContent: 'flex-end',
        flex: 0.7
    }
});