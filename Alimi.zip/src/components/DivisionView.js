import React, { Component } from 'react';
import { StyleSheet, Text, View, ScrollView } from 'react-native';
import axios from 'axios'

const DATA={};

export default class DivisionView extends Component {
    constructor(props) {
        super();
    }
    _doLogin = () => {
        if (this.state.user_id != '' || this.state.user_pw != '') {
            axios.get(`http://tktv.co.kr/api/shop/?id=${this.state.user_id}&password=${this.state.user_pw}`)
                .then(data => {
                    console.log(data);
                    if (data.data.response == "SUCCESS") {
                        AsyncStorage.setItem("ISLOGIN", JSON.stringify(true));
                        this.props.navigation.replace('AlimList');
                    }
                    else
                        alert('로그인에 실패하였습니다')
                });
        }
        else
            alert('아이디와 비밀번호를 입력해주세요')
    }
    componentDidMount = () => {
        this._doOpenApi();
    }
    
    _doOpenApi = () => {
        var parseString = require('react-native-xml2js').parseString;
        axios.get(`http://itktv.cafe24.com/alimi/manager/`).then(
            data => {
                parseString(data.data, function (err, result) {
                    console.dir(result);
                    result.VALUE.LIST["0"].rsv.map(function(ele,index){
                        DATA={
                            index:{
                                No:ele.No,
                                rdiv:ele.rdiv,
                                Name:ele.Name,
                                RPhone:ele.RPhone,
                                email:ele.email,
                                rloc:ele.rloc,
                                rjob:ele.rjob,
                                rclass:ele.rclass,
                                RDate:ele.RDate,
                                SubDate:ele.SubDate
                            },
                        }
                    })
                    DATA=[
                        {
                            No:
                            rdiv:
                            Name:
                            RPhone:
                            email:
                            rloc:
                            rjob:
                            rclass:
                            RDate:
                            SubDate:
                        }
                    ]
                })
            }
        );
    }
    render() {
        return (
            //플랫리스트
            <ScrollView style={{ flexDirection: 'column', width: '100%' }}>
                <View style={styles.oddviewstyle}>
                    <Text style={styles.division}>번호</Text>
                    <Text style={{ fontSize: 25 }}>0123</Text>
                </View>
                <View style={styles.evenviewstyle}>
                    <Text style={styles.division}>구분</Text>
                    <Text style={{ fontSize: 25 }}>예약</Text>
                </View>
                <View style={styles.oddviewstyle}>
                    <Text style={styles.division}>이름</Text>
                    <Text style={{ fontSize: 25 }}>홍길동</Text>
                </View>
                <View style={styles.evenviewstyle}>
                    <Text style={styles.division}>연락처</Text>
                    <Text style={{ fontSize: 25 }}>010-1234-5678</Text>
                </View>
                <View style={styles.oddviewstyle}>
                    <Text style={styles.division}>이메일</Text>
                    <Text style={{ fontSize: 25 }}>ghdrlfehd@google.com</Text>
                </View>
                <View style={styles.evenviewstyle}>
                    <Text style={styles.division}>지역</Text>
                    <Text style={{ fontSize: 25 }}>대구</Text>
                </View>
                <View style={styles.oddviewstyle}>
                    <Text style={styles.division}>소속</Text>
                    <Text style={{ fontSize: 25 }}>없음</Text>
                </View>
                <View style={styles.evenviewstyle}>
                    <Text style={styles.division}>클래스선택</Text>
                    <Text style={{ fontSize: 25 }}>2</Text>
                </View>
                <View style={styles.oddviewstyle}>
                    <Text style={styles.division}>예약일시</Text>
                    <Text style={{ fontSize: 25 }}>2017-01-01</Text>
                </View>
                <View style={styles.evenviewstyle}>
                    <Text style={styles.division}>등록일시</Text>
                    <Text style={{ fontSize: 25 }}>2017-01-01</Text>
                </View>
            </ScrollView>
        );
    }
}
const styles = StyleSheet.create({
    division: {
        fontSize: 20,
        color: 'orange',
        marginBottom: 5
    },
    oddviewstyle: {
        flexDirection: 'column',
        width: '100%',
        backgroundColor: '#D5D5D5',
        marginVertical: 5
    },
    evenviewstyel: {
        flexDirection: 'column',
        width: '100%',
        backgroundColor: '#fafafa',
        marginVertical: 5
    }
});